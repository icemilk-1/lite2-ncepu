"""Known-free A* planning with reachable-frontier exploration."""

import heapq
import math

import numpy as np


class PlanResult(object):
    __slots__ = ("status", "path", "goal_xy", "target_xy", "reason")

    def __init__(self, status, path=None, goal_xy=None, target_xy=None, reason=None):
        self.status = str(status)
        self.path = list(path or [])
        self.goal_xy = tuple(goal_xy) if goal_xy is not None else None
        self.target_xy = tuple(target_xy) if target_xy is not None else None
        self.reason = reason or self.status

    @property
    def has_path(self):
        return bool(self.path)


def plan_grid(grid, start, goal, radius_m, occupied_threshold, unknown_cost=2.8, preferred_clearance_m=0.0,
              clearance_preference_m=0.0, clearance_weight=0.0, clearance_threshold=None):
    """Plan to a known goal, or to a reachable frontier without changing the goal.

    ``goal`` may be ``None`` for pure mapping, in which case only the
    reachable-frontier branch runs and every result keeps ``goal_xy`` unset.

    When ``clearance_weight`` is positive the search prefers cells with a wide
    observed gap to the nearest wall. This keeps a 1 m pipe or a 1.2 m ramp
    corridor centred instead of hugging one inflated side, which is the
    dynamic-Voronoi idea from RTEB (Kulathunga 2025) reduced to a cost layer.
    ``clearance_threshold`` lets that cost layer see wall-like cells below the
    hard occupied threshold: terrain height jumps sit at log-odds ~0.35 and
    never reach 0.7, so using the occupied threshold here left every narrow
    corridor with no centring cost at all and the path hugged the wall.
    """
    start_xy = (float(start[0]), float(start[1]))
    goal_xy = None if goal is None else (float(goal[0]), float(goal[1]))
    start_cell = grid.world_to_cell(*start_xy)
    if start_cell is None:
        return PlanResult("start_out_of_map", goal_xy=goal_xy)
    goal_cell = None
    if goal_xy is not None:
        goal_cell = grid.world_to_cell(*goal_xy)
        if goal_cell is None:
            return PlanResult("goal_out_of_map", goal_xy=goal_xy)

    values = grid.log_odds
    known_free = values <= -0.18
    occupied = values >= occupied_threshold
    unknown = ~(known_free | occupied)
    hazard = getattr(grid, "terrain_hazard", None)
    if hazard is not None:
        hazard = np.asarray(hazard, dtype=bool)
    # Terrain hazards are already part of the inflated hard mask (TerrainGrid adds
    # them), but they must NOT join the preferred_clearance layer: that layer also
    # gates the reachability flood fill, and inflating hazard cells by radius +
    # planning clearance swallowed the start pose next to a rubble edge and turned
    # the whole map into "no reachable frontier".  Anti-hugging is handled by the
    # clearance cost and by the smoothing layer below.
    blocked = grid.inflated(radius_m, occupied_threshold)
    preferred_blocked = grid.inflated(radius_m + preferred_clearance_m, occupied_threshold)
    clearance = None
    if clearance_weight > 0.0 and clearance_preference_m > 0.0 and hasattr(grid, "clearance"):
        clearance = grid.clearance(occupied_threshold if clearance_threshold is None
                                   else clearance_threshold)
    sx, sy = start_cell

    if not known_free[sy, sx] and not occupied[sy, sx]:
        return PlanResult("insufficient_observations", goal_xy=goal_xy,
                          reason="start_pose_not_observed_free")
    if occupied[sy, sx] or blocked[sy, sx]:
        return PlanResult("start_blocked", goal_xy=goal_xy, reason="start_not_known_traversable")

    traversable = known_free & ~blocked
    smoothing_blocked = preferred_blocked | ~known_free
    smoothing_blocked |= getattr(grid, "height_discontinuities", False)
    if clearance_threshold is not None and float(clearance_threshold) < float(occupied_threshold):
        # Wall-like cells sit below the occupied threshold, so neither the hard
        # inflation nor the smoothing shortcut layer sees them; smoothing then
        # collapses the centred A* route back onto a straight wall-hugging line.
        # Block shortcuts with the same reference distance the cost layer uses,
        # so the final path keeps the corridor centre line.
        keep_clear = max(float(radius_m), float(clearance_preference_m))
        smoothing_blocked |= grid.inflated(keep_clear, float(clearance_threshold), hazard)
    if goal_xy is not None:
        gx, gy = goal_cell
        if occupied[gy, gx] or blocked[gy, gx]:
            # A checkpoint centre can land on a scan artefact or on the inflated
            # band of a wall corner even though the checkpoint region (radius 0.25)
            # is reachable.  Snap to the nearest traversable cell inside the
            # tolerance instead of declaring the whole goal blocked.
            snap = max(1, int(round(float(getattr(grid, "goal_snap_radius_m", 0.30)) /
                                    grid.resolution)))
            best = None
            for dy in range(-snap, snap + 1):
                for dx in range(-snap, snap + 1):
                    if dx * dx + dy * dy > snap * snap:
                        continue
                    row, column = gy + dy, gx + dx
                    if not (0 <= row < traversable.shape[0] and 0 <= column < traversable.shape[1]):
                        continue
                    if traversable[row, column] and known_free[row, column]:
                        distance = dx * dx + dy * dy
                        if best is None or distance < best[0]:
                            best = (distance, column, row)
            if best is None:
                nearby_unknown = unknown[max(0, gy-snap):gy+snap+1, max(0, gx-snap):gx+snap+1].any()
                if occupied[gy, gx] or not nearby_unknown:
                    return PlanResult("goal_blocked", goal_xy=goal_xy,
                                      reason="goal_occupied_or_clearance_blocked")
                # Observe an unconfirmed approach area before treating a distant
                # inflated goal as a local recovery problem.
            else:
                _, gx, gy = best
                goal_cell = (gx, gy)
        if traversable[gy, gx]:
            path_cells, _, _ = _a_star(grid, start_cell, goal_cell, traversable, preferred_blocked,
                                       clearance, clearance_preference_m, clearance_weight)
            if path_cells is not None:
                path = _cells_to_world(grid, grid.smooth(path_cells, smoothing_blocked))
                if not path:
                    path = [start_xy]
                return PlanResult("path_found", path, goal_xy, goal_xy)

    # The exact target remains unchanged. Explore only free cells reachable
    # from the robot and select one bordering unobserved space.
    distances, parents = _reachable_costs(grid, start_cell, traversable, preferred_blocked)
    height, width = values.shape
    explorable_unknown = unknown & ~blocked
    frontier_band = explorable_unknown.copy()
    frontier_radius = getattr(grid, "frontier_radius_m", 0.0)
    if frontier_radius > 0:
        for _ in range(int(math.ceil(frontier_radius / grid.resolution))):
            expanded = frontier_band.copy()
            expanded[1:, :] |= frontier_band[:-1, :]
            expanded[:-1, :] |= frontier_band[1:, :]
            expanded[:, 1:] |= frontier_band[:, :-1]
            expanded[:, :-1] |= frontier_band[:, 1:]
            frontier_band |= expanded & ~blocked
    visited = getattr(grid, "frontier_visits", None)
    visits_threshold = float(getattr(grid, "frontier_visits_threshold", math.inf))
    rearward_penalty = float(getattr(grid, "frontier_rearward_penalty", 0.0))
    heading = getattr(grid, "frontier_heading_rad", None)
    frontier_cells = []
    minimum_distance = float(getattr(grid, "frontier_min_distance_m", 0.55))
    for (column, row), cost in distances.items():
        if visited is not None and visited[row, column] > visits_threshold:
            continue
        if not (frontier_band[row, column] if frontier_radius > 0 else _touches_unknown(explorable_unknown, column, row, width, height)):
            continue
        frontier_xy = grid.cell_to_world(column, row)
        score = cost * grid.resolution
        if goal_xy is not None:
            remaining = math.hypot(goal_xy[0] - frontier_xy[0], goal_xy[1] - frontier_xy[1])
            remaining_weight = max(1.0, min(2.5, float(unknown_cost) / 1.75))
            score += remaining_weight * remaining
        if visited is not None:
            score += 3.0 * min(float(visited[row, column]), 3.0)
        if heading is not None and rearward_penalty > 0:
            facing = math.cos(math.atan2(frontier_xy[1] - start_xy[1],
                                         frontier_xy[0] - start_xy[0]) - heading)
            if facing < 0.0:
                # Keep exploring forward while forward options exist, but allow a
                # rearward frontier once the front is exhausted.
                score += rearward_penalty * (-facing)
        frontier_cells.append((score, cost, row, column))
    if not frontier_cells:
        if goal_xy is not None and traversable[goal_cell[1], goal_cell[0]]:
            return PlanResult("map_disconnected", goal_xy=goal_xy, reason="known_goal_not_reachable")
        return PlanResult("insufficient_observations", goal_xy=goal_xy,
                          reason="no_reachable_known_free_frontier")
    # The lidar blind spot under the robot is permanently unobserved, so a
    # frontier right next to the body would be re-selected forever and turn the
    # robot into a spinner. Prefer frontiers that need real travel.
    distant = [cell for cell in frontier_cells if cell[1] * grid.resolution >= minimum_distance]
    _, _, row, column = min(distant or frontier_cells)
    frontier = (column, row)
    path_cells = _reconstruct(parents, start_cell, frontier)
    path = _cells_to_world(grid, grid.smooth(path_cells, smoothing_blocked))
    if not path:
        path = [start_xy]
    target_xy = grid.cell_to_world(column, row)
    return PlanResult("exploring", path, goal_xy, target_xy,
                      reason="goal_not_observed_reachable_frontier_selected")


def _neighbors(cell, width, height, traversable, grid=None):
    x, y = cell
    for dx, dy, step in ((-1, 0, 1.0), (1, 0, 1.0), (0, -1, 1.0), (0, 1, 1.0),
                         (-1, -1, math.sqrt(2.0)), (-1, 1, math.sqrt(2.0)),
                         (1, -1, math.sqrt(2.0)), (1, 1, math.sqrt(2.0))):
        nx, ny = x + dx, y + dy
        if not (0 <= nx < width and 0 <= ny < height) or not traversable[ny, nx]:
            continue
        if dx and dy and (not traversable[y, nx] or not traversable[ny, x]):
            continue
        if (grid is not None and hasattr(grid, "height_m")
                and grid.clock_s - min(grid.height_updated_s[y, x], grid.height_updated_s[ny, nx])
                <= float(grid.settings.get("height_observation_timeout_s", 0.5))):
            current_height, next_height = grid.height_m[y, x], grid.height_m[ny, nx]
            allowed = (grid.settings.get("surface_height_tolerance_m", 0.02)
                       + grid.resolution * step * math.tan(math.radians(grid.settings["max_slope_deg"])))
            if np.isfinite(current_height) and np.isfinite(next_height) and abs(next_height-current_height) > allowed:
                continue
        yield (nx, ny), step


def _a_star(grid, start, goal, traversable, preferred_blocked, clearance=None,
            clearance_preference_m=0.0, clearance_weight=0.0):
    height, width = traversable.shape

    def heuristic(cell):
        return math.hypot(goal[0] - cell[0], goal[1] - cell[1])

    frontier = [(heuristic(start), 0.0, start)]
    parents = {}
    costs = {start: 0.0}
    while frontier:
        _, cost, current = heapq.heappop(frontier)
        if current == goal:
            return _reconstruct(parents, start, goal), parents, costs
        if cost > costs.get(current, math.inf):
            continue
        for nxt, step in _neighbors(current, width, height, traversable, grid):
            extra = 2.0 if preferred_blocked[nxt[1], nxt[0]] else 0.0
            if clearance is not None:
                gap = float(clearance[nxt[1], nxt[0]])
                if math.isfinite(gap):
                    # Zero at the preferred gap, growing as the path is pushed
                    # towards an observed wall; this centres narrow corridors.
                    extra += clearance_weight * max(0.0, 1.0 - min(1.0, gap / clearance_preference_m))
            next_cost = cost + step * (1.0 + extra)
            if next_cost < costs.get(nxt, math.inf):
                costs[nxt] = next_cost
                parents[nxt] = current
                heapq.heappush(frontier, (next_cost + heuristic(nxt), next_cost, nxt))
    return None, parents, costs


def _reachable_costs(grid, start, traversable, preferred_blocked):
    height, width = traversable.shape
    frontier = [(0.0, start)]
    parents = {}
    costs = {start: 0.0}
    while frontier:
        cost, current = heapq.heappop(frontier)
        if cost > costs.get(current, math.inf):
            continue
        for nxt, step in _neighbors(current, width, height, traversable, grid):
            extra = 2.0 if preferred_blocked[nxt[1], nxt[0]] else 0.0
            next_cost = cost + step * (1.0 + extra)
            if next_cost < costs.get(nxt, math.inf):
                costs[nxt] = next_cost
                parents[nxt] = current
                heapq.heappush(frontier, (next_cost, nxt))
    return costs, parents


def _touches_unknown(unknown, column, row, width, height):
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        x, y = column + dx, row + dy
        if 0 <= x < width and 0 <= y < height and unknown[y, x]:
            return True
    return False


def _reconstruct(parents, start, goal):
    cells = [goal]
    while cells[-1] != start:
        parent = parents.get(cells[-1])
        if parent is None:
            return []
        cells.append(parent)
    cells.reverse()
    return cells


def _cells_to_world(grid, cells):
    return [grid.cell_to_world(column, row) for column, row in cells]